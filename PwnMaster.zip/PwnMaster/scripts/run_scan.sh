#!/bin/bash

# ──────────────────────────────────────────────
# 🔥 All-In-One Hacking Tool - Scan Script 🔥
# ──────────────────────────────────────────────

# Colors
GREEN="\033[1;32m"
RED="\033[1;31m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
WHITE="\033[1;37m"
RESET="\033[0m"

# Banner
echo -e "${BLUE}🚀 Starting All-In-One Scan...${RESET}"

# Set Paths
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN_PY="$PROJECT_ROOT/main.py"
CONFIG_FILE="$PROJECT_ROOT/config.yaml"
LOG_FILE="$PROJECT_ROOT/logs/run_scan.log"

# Ensure logs directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Check for main.py
if [ ! -f "$MAIN_PY" ]; then
    echo -e "${RED}❌ [ERROR] main.py not found in expected location: $MAIN_PY${RESET}"
    echo -e "${YELLOW}🔍 Searching for main.py...${RESET}"
    
    MAIN_PY_FOUND=$(find "$PROJECT_ROOT" -type f -name "main.py" | head -n 1)
    
    if [ -z "$MAIN_PY_FOUND" ]; then
        echo -e "${RED}❌ [ERROR] main.py is missing! Please re-run setup.sh.${RESET}"
        exit 1
    else
        echo -e "${GREEN}✅ [INFO] Found main.py at: $MAIN_PY_FOUND${RESET}"
        ln -sf "$MAIN_PY_FOUND" "$MAIN_PY"
    fi
fi

# Check for config.yaml
if [ ! -f "$CONFIG_FILE" ]; then
    echo -e "${RED}❌ [ERROR] config.yaml not found! Please re-run setup.sh.${RESET}"
    exit 1
fi

# Parse Arguments
if [ "$#" -lt 1 ]; then
    echo -e "${YELLOW}Usage: ./scripts/run_scan.sh <target-domain> [--no-exploit]${RESET}"
    exit 1
fi

TARGET="$1"
NO_EXPLOIT=""

if [ "$2" == "--no-exploit" ]; then
    NO_EXPLOIT="--no-exploit"
fi

# Start Scan
echo -e "${GREEN}🚀 [INFO] Running scan for domain: $TARGET ${RESET}"
python3 "$MAIN_PY" "$TARGET" $NO_EXPLOIT 2>&1 | tee "$LOG_FILE"

# Final Message
echo -e "${WHITE}🏁 [INFO] Scan completed. Logs saved to: $LOG_FILE${RESET}"
