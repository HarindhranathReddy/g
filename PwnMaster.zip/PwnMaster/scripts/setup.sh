#!/bin/bash

# ──────────────────────────────────────────────
# 🔥 All-In-One Hacking Tool - Setup Script 🔥
# ──────────────────────────────────────────────

# Colors
GREEN="\033[1;32m"
RED="\033[1;31m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
WHITE="\033[1;37m"
RESET="\033[0m"

echo -e "${BLUE}🚀 Starting Setup...${RESET}"

# Ensure Running as Root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ [ERROR] Please run this script as root (sudo ./scripts/setup.sh)${RESET}"
    exit 1
fi

# Update & Upgrade System
echo -e "${GREEN}🔄 [INFO] Updating system packages...${RESET}"
apt update && apt upgrade -y

# Install Required Dependencies
echo -e "${GREEN}🛠 [INFO] Installing dependencies...${RESET}"
DEPS=(python3 python3-pip git amass subfinder gobuster wfuzz assetfinder sqlmap nuclei curl wget tor proxychains-ng)
for dep in "${DEPS[@]}"; do
    if ! command -v "$dep" &> /dev/null; then
        echo -e "${YELLOW}⚠ [WARNING] $dep not found! Installing...${RESET}"
        apt install -y "$dep"
    else
        echo -e "${GREEN}✅ [INFO] $dep is already installed.${RESET}"
    fi
done

# Install Python Libraries
echo -e "${GREEN}🐍 [INFO] Installing Python libraries...${RESET}"
pip3 install --no-cache-dir httpx tqdm requests pyyaml openai colorama || \
    { echo -e "${RED}❌ [ERROR] Failed to install Python libraries! Check your Python/Pip setup.${RESET}"; exit 1; }

# Set Paths
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_FILE="$PROJECT_ROOT/config.yaml"
LOGS_DIR="$PROJECT_ROOT/logs"
OUTPUT_DIR="$PROJECT_ROOT/output"
SCRIPTS_DIR="$PROJECT_ROOT/scripts"

# Create Necessary Directories
mkdir -p "$LOGS_DIR" "$OUTPUT_DIR" "$SCRIPTS_DIR"

# Fix Permissions
echo -e "${GREEN}🔧 [INFO] Fixing file permissions...${RESET}"
chmod +x "$SCRIPTS_DIR"/*.sh || echo -e "${RED}⚠ [WARNING] No scripts found in scripts/ directory!${RESET}"

# Check if main.py Exists
MAIN_PY="$PROJECT_ROOT/tool/main.py"
if [ ! -f "$MAIN_PY" ]; then
    echo -e "${RED}❌ [ERROR] main.py not found in expected location: $MAIN_PY${RESET}"
    echo -e "${YELLOW}🔍 Searching for main.py...${RESET}"
    
    MAIN_PY_FOUND=$(find "$PROJECT_ROOT" -type f -name "main.py" | head -n 1)
    if [ -z "$MAIN_PY_FOUND" ]; then
        echo -e "${RED}❌ [ERROR] main.py is missing! Please check the installation.${RESET}"
        exit 1
    else
        echo -e "${GREEN}✅ [INFO] Found main.py at: $MAIN_PY_FOUND${RESET}"
        ln -sf "$MAIN_PY_FOUND" "$PROJECT_ROOT/tool/main.py"
    fi
fi

# Ask User About Proxy & AI
read -p "🌍 Do you want to enable proxy mode? (y/n): " ENABLE_PROXY
read -p "🤖 Do you want to enable AI-powered payloads? (y/n): " ENABLE_AI

# Update Config File
if [ "$ENABLE_PROXY" == "y" ]; then
    sed -i 's/enable_proxy: false/enable_proxy: true/' "$CONFIG_FILE"
    echo -e "${GREEN}✅ [INFO] Proxy mode enabled!${RESET}"
fi

if [ "$ENABLE_AI" == "y" ]; then
    read -p "🔑 Enter your OpenAI API Key: " OPENAI_KEY
    sed -i "s|openai_api_key: .*|openai_api_key: \"$OPENAI_KEY\"|" "$CONFIG_FILE"
    sed -i 's/use_ai_payloads: false/use_ai_payloads: true/' "$CONFIG_FILE"
    echo -e "${GREEN}✅ [INFO] AI-powered payloads enabled!${RESET}"
fi

# Final Message
echo -e "${WHITE}🏁 [INFO] Setup completed successfully! Run ./scripts/run_scan.sh <target>${RESET}"
