import random
import yaml
import os

# Load configuration from config.yaml
config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

PROXIES = config.get("proxy_settings", {}).get("proxy_list", []) if config.get("proxy_settings", {}).get("enable_proxy", False) else []

def get_random_proxy():
    """Returns a random proxy from the list if random selection is enabled."""
    if config.get("proxy_settings", {}).get("use_random_proxy", False) and PROXIES:
        return random.choice(PROXIES)
    return None

def get_proxies():
    """Returns a dictionary of proxies for use with HTTP libraries."""
    proxy = get_random_proxy()
    return {"http": proxy, "https": proxy} if proxy else {}
