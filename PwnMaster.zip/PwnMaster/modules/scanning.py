import asyncio
import httpx
import os
import yaml
import random
from colorama import Fore, Style, init
from tqdm import tqdm  # Progress bar for better UX
from modules.utils import print_status

# Initialize colorful output
init(autoreset=True)

# Load Configuration
CONFIG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
try:
    with open(CONFIG_PATH, "r") as f:
        config = yaml.safe_load(f)
except FileNotFoundError:
    print_status("❌ [ERROR] config.yaml not found!", "error")
    exit(1)

# Extract settings
PROXY_ENABLED = config.get("proxy_settings", {}).get("enable_proxy", False)
PROXY_LIST = config.get("proxy_settings", {}).get("proxy_list", [])
THREADS = config.get("threads", 10)  # Number of concurrent scans
VERBOSE = config.get("verbose_mode", True)

# Output paths
OUTPUT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../output/"))
LIVE_URLS_FILE = os.path.join(OUTPUT_DIR, "live-urls.txt")
SUBS_FILE = os.path.join(OUTPUT_DIR, "subs.txt")

# Ensure output directory exists
os.makedirs(OUTPUT_DIR, exist_ok=True)

async def check_url(url, client):
    """Checks if a URL is live and prints real-time status."""
    try:
        response = await client.get(url, timeout=8)
        status = response.status_code

        if status == 200:
            print_status(f"✅ [LIVE] {url} (200 OK)", "success")
            return url
        elif status in [301, 302]:
            print_status(f"🔄 [REDIRECT] {url} → {response.headers.get('Location', 'Unknown')}", "info")
        elif status == 403:
            print_status(f"⛔ [FORBIDDEN] {url} (403)", "warning")
        elif status == 500:
            print_status(f"🔥 [SERVER ERROR] {url} (500)", "fire")
        else:
            print_status(f"⚠️  [UNKNOWN] {url} (Status: {status})", "warning")

    except httpx.RequestError as e:
        print_status(f"❌ [ERROR] {url} - {e}", "error")

    return None

async def find_live_urls_async(subdomains):
    """Runs live URL probing asynchronously using httpx."""
    live_urls = set()
    
    # Configure proxy if enabled
    proxies = {"http://": random.choice(PROXY_LIST), "https://": random.choice(PROXY_LIST)} if PROXY_ENABLED else None

    async with httpx.AsyncClient(proxies=proxies, headers={"User-Agent": "Mozilla/5.0"}) as client:
        tasks = []
        for domain in subdomains:
            for scheme in ["http://", "https://"]:
                url = f"{scheme}{domain}"
                tasks.append(check_url(url, client))

        results = await asyncio.gather(*tasks)
        for res in results:
            if res:
                live_urls.add(res)

    return live_urls

def find_live_urls():
    """Reads subdomains, checks for live URLs, and saves them."""
    if not os.path.exists(SUBS_FILE):
        print_status(f"❌ [ERROR] Subdomains file not found: {SUBS_FILE}", "error")
        return

    with open(SUBS_FILE, "r") as f:
        subdomains = [line.strip() for line in f if line.strip()]

    print_status("🌐 [INFO] Probing live URLs...", "start")
    live_urls = asyncio.run(find_live_urls_async(subdomains))

    # Save live URLs
    with open(LIVE_URLS_FILE, "w") as f:
        for url in live_urls:
            f.write(url + "\n")

    print_status(f"✅ [SUCCESS] Found {len(live_urls)} live URLs! Results saved to {LIVE_URLS_FILE}", "success")
