import random
import yaml
import os
import requests

# Load configuration from config.yaml
config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

USER_AGENTS = config.get("waf_bypass", {}).get("user_agents", ["Mozilla/5.0"])
ENABLE_HEADER_ROTATION = config.get("waf_bypass", {}).get("enable_header_rotation", True)
USE_TLS_FINGERPRINT_EVASION = config.get("waf_bypass", {}).get("enable_tls_fingerprint_evasion", False)

def get_random_user_agent():
    """Return a random User-Agent string if header rotation is enabled."""
    return random.choice(USER_AGENTS) if ENABLE_HEADER_ROTATION else "Mozilla/5.0"

def get_headers():
    """Construct and return HTTP headers for WAF bypass."""
    headers = {
        "User-Agent": get_random_user_agent(),
        "Referer": "https://www.google.com",
        "X-Forwarded-For": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
    }
    return headers

def waf_bypass_request(url, session=None):
    """
    Perform an HTTP GET request to the specified URL with custom headers
    designed to bypass basic WAF and firewall restrictions.
    """
    headers = get_headers()
    try:
        if session:
            response = session.get(url, headers=headers, timeout=10)
        else:
            response = requests.get(url, headers=headers, timeout=10)
        return response
    except Exception as e:
        print(f"[ERROR] WAF bypass request failed: {e}")
        return None
