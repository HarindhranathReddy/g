import os
import yaml
import openai
from colorama import Fore, Style, init
from modules.utils import print_status

# Initialize colorful output
init(autoreset=True)

# Load Configuration
CONFIG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
try:
    with open(CONFIG_PATH, "r") as f:
        config = yaml.safe_load(f)
except FileNotFoundError:
    print_status("❌ [ERROR] config.yaml not found!", "error")
    exit(1)

# Extract API Key
OPENAI_API_KEY = config.get("openai_api_key", "")

# Ensure OpenAI API Key is set
if not OPENAI_API_KEY:
    print_status("⚠️  [WARNING] OpenAI API Key is missing! Using default payloads.", "warning")

# OpenAI Configuration
openai.api_key = OPENAI_API_KEY

# Default Payloads (Used when OpenAI fails)
DEFAULT_PAYLOADS = {
    "SQLi": "' OR 1=1 --",
    "XSS": "<script>alert('XSS')</script>",
    "SSRF": "file:///etc/passwd",
    "LFI": "../../../../etc/passwd",
}

def generate_payload(vuln_type):
    """Generates an AI-powered payload for a specific vulnerability type."""
    if not OPENAI_API_KEY:
        return DEFAULT_PAYLOADS.get(vuln_type, "")

    prompt = f"""
    You are an advanced penetration tester. Generate a stealthy and unique payload for {vuln_type} 
    that can bypass modern WAFs and filters. Include encoding/obfuscation techniques if necessary.
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=50
        )
        payload = response["choices"][0]["message"]["content"].strip()

        if payload:
            print_status(f"🧠 [AI PAYLOAD] {payload}", "debug")
            return payload
        else:
            print_status(f"⚠️  [WARNING] OpenAI returned an empty payload. Using default.", "warning")
            return DEFAULT_PAYLOADS.get(vuln_type, "")

    except Exception as e:
        print_status(f"❌ [ERROR] OpenAI API failed: {e}. Using default payload.", "error")
        return DEFAULT_PAYLOADS.get(vuln_type, "")

