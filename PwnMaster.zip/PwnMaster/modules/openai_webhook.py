import openai
import yaml
import os

# Load configuration from config.yaml
config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

OPENAI_API_KEY = config.get("openai_api_key", "")

def send_report(vulnerability, target, details):
    """
    Uses the OpenAI API to generate a detailed security report based on the vulnerability type,
    target, and additional details provided. Returns the generated report text.
    """
    prompt = (
        f"Generate a detailed security report for a vulnerability of type '{vulnerability}' "
        f"found on target '{target}'. Details: {details}. The report should be professional, "
        "comprehensive, and include recommendations for remediation."
    )
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": prompt}],
            api_key=OPENAI_API_KEY
        )
        report = response["choices"][0]["message"]["content"].strip()
        return report
    except Exception as e:
        return f"Error generating report: {e}"
