import asyncio
import subprocess
import os
import yaml
from tqdm import tqdm  # For real-time progress bar
from colorama import Fore, Style, init
from modules.utils import print_status

# Initialize colorful output
init(autoreset=True)

# Load configuration
CONFIG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
try:
    with open(CONFIG_PATH, "r") as f:
        config = yaml.safe_load(f)
except FileNotFoundError:
    print_status("❌ [ERROR] config.yaml not found!", "error")
    exit(1)

# Extract settings
PROXY_ENABLED = config.get("proxy_settings", {}).get("enable_proxy", False)
PROXY_LIST = config.get("proxy_settings", {}).get("proxy_list", [])
VERBOSE = config.get("verbose_mode", True)

# Subdomain Enumeration Tools
TOOLS = {
    "subfinder": "subfinder -d {target} -silent",
    "amass": "amass enum -passive -d {target}",
    "findomain": "findomain -t {target} -q",
}

# File paths
OUTPUT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../output/"))
SUBS_FILE = os.path.join(OUTPUT_DIR, "subs.txt")

# Ensure output directory exists
os.makedirs(OUTPUT_DIR, exist_ok=True)

async def run_tool(command):
    """Runs a command asynchronously and captures the output."""
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL
        )
        stdout, _ = await process.communicate()
        return stdout.decode().splitlines()
    except Exception as e:
        print_status(f"❌ [ERROR] Failed to execute: {command}. Error: {e}", "error")
        return []

async def find_subdomains(target):
    """Runs multiple subdomain enumeration tools asynchronously."""
    print_status(f"🔍 [INFO] Finding subdomains for {target}...", "start")

    tasks = []
    for tool, command in TOOLS.items():
        full_command = command.format(target=target)
        if PROXY_ENABLED:
            full_command += f" -proxy {random.choice(PROXY_LIST)}"
        tasks.append(run_tool(full_command))

    results = await asyncio.gather(*tasks)

    # Merge results, remove duplicates
    all_subdomains = sorted(set(sub for result in results for sub in result))

    if all_subdomains:
        print_status(f"✅ [SUCCESS] Found {len(all_subdomains)} subdomains!", "success")
        with open(SUBS_FILE, "w") as f:
            for sub in all_subdomains:
                f.write(sub + "\n")
                print_status(f"🌐 [LIVE] {sub}", "debug")
    else:
        print_status("⚠️ [WARNING] No subdomains found!", "warning")

    return all_subdomains
