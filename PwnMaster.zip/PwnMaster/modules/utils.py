import os
import time
import logging
import yaml
from colorama import Fore, Style, init

# Initialize color output
init(autoreset=True)

# Load Configuration
CONFIG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../config.yaml"))
try:
    with open(CONFIG_PATH, "r") as f:
        config = yaml.safe_load(f)
except FileNotFoundError:
    print("\033[1;31m❌ [ERROR] config.yaml not found! Ensure it's in the root directory.\033[0m")
    exit(1)

# Extract settings
VERBOSE_MODE = config.get("verbose_mode", True)

# Log File Setup
LOG_FILE = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../logs/tool.log"))
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def print_status(message, status_type="info"):
    """
    Prints status messages with terminal emojis and colors.
    
    Types:
      - info: ℹ️ (Blue)
      - success: ✅ (Green)
      - warning: ⚠️ (Yellow)
      - error: ❌ (Red)
      - debug: 🐞 (Magenta)
      - start: 🚀 (Cyan)
      - end: 🏁 (White)
      - fire: 🔥 (Light Red)
      - exploit: 💥 (Light Yellow)
    """
    emojis = {
        "info": "ℹ️",
        "success": "✅",
        "warning": "⚠️",
        "error": "❌",
        "debug": "🐞",
        "start": "🚀",
        "end": "🏁",
        "fire": "🔥",
        "exploit": "💥"
    }
    colors = {
        "info": Fore.BLUE,
        "success": Fore.GREEN,
        "warning": Fore.YELLOW,
        "error": Fore.RED,
        "debug": Fore.MAGENTA,
        "start": Fore.CYAN,
        "end": Fore.WHITE,
        "fire": Fore.LIGHTRED_EX,
        "exploit": Fore.LIGHTYELLOW_EX
    }
    
    emoji = emojis.get(status_type, "")
    color = colors.get(status_type, Fore.WHITE)
    log_level = {
        "info": logging.INFO,
        "success": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "debug": logging.DEBUG,
        "start": logging.INFO,
        "end": logging.INFO,
        "fire": logging.WARNING,
        "exploit": logging.INFO
    }

    # Print to terminal (only in verbose mode)
    if VERBOSE_MODE:
        print(f"{emoji} {color}{message}{Style.RESET_ALL}")
    
    # Log to file
    logging.log(log_level[status_type], message)

class Timer:
    """Utility class for tracking execution time of different phases."""
    def __init__(self):
        self.start_time = time.time()

    def elapsed_time(self):
        return time.time() - self.start_time

    def print_elapsed(self, phase_name):
        elapsed = self.elapsed_time()
        print_status(f"⏳ [INFO] {phase_name} completed in {elapsed:.2f} seconds.", "info")

def handle_interrupt():
    """Handles keyboard interruptions (CTRL+C) gracefully."""
    try:
        while True:
            pass  # Keep the script running
    except KeyboardInterrupt:
        print_status("⚠️  [WARNING] Process interrupted by user! Exiting safely...", "warning")
        exit(1)
